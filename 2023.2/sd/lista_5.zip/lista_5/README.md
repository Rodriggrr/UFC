# How to run
```bash
./run <file.cpp>
```
